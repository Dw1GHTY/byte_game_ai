def prevedi_slovo_u_broj(slovo):
    broj = ord(slovo) - ord('A')
    return broj
