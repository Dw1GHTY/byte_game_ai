from Igra import *


def main():
    start_game()

if __name__ == '__main__':
    main()


